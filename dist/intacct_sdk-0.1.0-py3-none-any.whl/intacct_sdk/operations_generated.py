from __future__ import annotations

from typing import Optional, Dict

from . import xml as xml_builder
from .models import ResultData


class OperationMixin:
    def execute(
        self,
        operation: str,
        payload: Optional[xml_builder.Payload] = None,
        operation_attrs: Optional[Dict[str, str]] = None,
        control_id: Optional[str] = None,
    ) -> ResultData:
        raise NotImplementedError

    def apply_arpayment(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("apply_arpayment", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def approve(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("approve", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def approve_appaymentrequest(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("approve_appaymentrequest", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def approve_vendor(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("approveVendor", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def cancel(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("cancel", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def clearallmea(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("clearallmea", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def clearlastactivemea(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("clearlastactivemea", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def confirm_appaymentrequest(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("confirm_appaymentrequest", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def consolidate(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("consolidate", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def consolidatebytier(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("consolidatebytier", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_achbankconfiguration(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_achbankconfiguration", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_apaccountlabel(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_apaccountlabel", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_apadjustment(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_apadjustment", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_apadjustmentbatch(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_apadjustmentbatch", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_appayment(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_appayment", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_apterm(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_apterm", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_araccountlabel(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_araccountlabel", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_aradjustment(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_aradjustment", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_aradjustmentbatch(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_aradjustmentbatch", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_arpayment(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_arpayment", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_arpaymentbatch(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_arpaymentbatch", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_arterm(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_arterm", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_bill(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_bill", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_billbatch(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_billbatch", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_class(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_class", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_consolidation(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_consolidation", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_contact(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_contact", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_contacttaxgroup(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_contacttaxgroup", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_customer(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_customer", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_customerbankaccount(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_customerbankaccount", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_customerchargecard(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_customerchargecard", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_department(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_department", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_earningtype(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_earningtype", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_employee(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_employee", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_employeerate(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_employeerate", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_expenseadjustmentreport(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_expenseadjustmentreport", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_expensepaymenttype(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_expensepaymenttype", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_expensereport(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_expensereport", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_expensereportbatch(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_expensereportbatch", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_expensetype(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_expensetype", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_glaccount(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_glaccount", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_gltransaction(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_gltransaction", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_ictransaction(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_ictransaction", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_invoice(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_invoice", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_invoicebatch(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_invoicebatch", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_item(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_item", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_itemtaxgroup(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_itemtaxgroup", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_location(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_location", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_paymentrequest(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_paymentrequest", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_popricelist(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_popricelist", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_potransaction(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_potransaction", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_recurringbill(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_recurringbill", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_recurringinvoice(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_recurringinvoice", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_recursotransaction(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_recursotransaction", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_reimbursementrequest(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_reimbursementrequest", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_savingsaccount(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_savingsaccount", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_sopricelist(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_sopricelist", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_sotransaction(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_sotransaction", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_statglaccount(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_statglaccount", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_statgltransaction(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_statgltransaction", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_stkittransaction(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_stkittransaction", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_supdoc(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_supdoc", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_supdocfolder(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_supdocfolder", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_task(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_task", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_territory(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_territory", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_timesheet(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_timesheet", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_timetype(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_timetype", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_vendor(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_vendor", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def create_vendorentityaccountno(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("create_vendorentityaccountno", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def decline(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("decline", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def decline_appaymentrequest(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("decline_appaymentrequest", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def decline_vendor(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("declineVendor", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_achbankconfiguration(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_achbankconfiguration", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_apaccountlabel(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_apaccountlabel", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_apadjustment(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_apadjustment", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_apterm(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_apterm", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_araccountlabel(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_araccountlabel", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_aradjustment(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_aradjustment", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_arterm(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_arterm", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_bill(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_bill", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_class(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_class", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_contact(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_contact", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_contacttaxgroup(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_contacttaxgroup", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_customer(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_customer", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_customerbankaccount(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_customerbankaccount", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_customerchargecard(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_customerchargecard", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_department(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_department", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_earningtype(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_earningtype", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_employee(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_employee", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_employeerate(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_employeerate", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_expenseadjustmentreport(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_expenseadjustmentreport", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_expensepaymenttype(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_expensepaymenttype", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_expensereport(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_expensereport", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_expensetype(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_expensetype", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_glaccount(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_glaccount", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_gltransaction(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_gltransaction", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_ictransaction(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_ictransaction", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_invoice(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_invoice", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_item(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_item", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_itemtaxgroup(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_itemtaxgroup", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_location(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_location", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_otherreceipt(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_otherreceipt", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_paymentrequest(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_paymentrequest", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_popricelist(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_popricelist", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_potransaction(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_potransaction", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_recurringbill(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_recurringbill", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_recurringinvoice(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_recurringinvoice", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_recursotransaction(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_recursotransaction", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_savingsaccount(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_savingsaccount", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_sopricelist(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_sopricelist", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_sotransaction(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_sotransaction", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_statglaccount(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_statglaccount", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_supdoc(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_supdoc", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_supdocfolder(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_supdocfolder", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_task(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_task", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_territory(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_territory", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_timesheet(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_timesheet", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_timetype(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_timetype", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def delete_vendor(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("delete_vendor", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def deliver(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("deliver", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def get(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("get", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def get_accountbalances(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("get_accountbalances", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def get_accountbalancesbydimensions(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("get_accountbalancesbydimensions", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def get_apisession(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("getAPISession", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def get_applications(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("get_applications", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def get_approval_history(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("getApprovalHistory", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def get_araging(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("get_araging", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def get_audit_trail(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("getAuditTrail", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def get_companyprefs(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("get_companyprefs", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def get_dds_ddl(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("getDdsDdl", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def get_dds_objects(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("getDdsObjects", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def get_dimension_autofill_details(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("getDimensionAutofillDetails", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def get_dimension_relationships(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("getDimensionRelationships", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def get_dimension_restricted_data(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("getDimensionRestrictedData", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def get_dimension_restrictions(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("getDimensionRestrictions", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def get_dimensions(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("getDimensions", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def get_financial_setup(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("getFinancialSetup", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def get_list(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("get_list", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def get_transactions_to_approve(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("getTransactionsToApprove", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def get_trialbalance(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("get_trialbalance", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def get_user_permissions(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("getUserPermissions", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def get_vendor_approval_history(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("getVendorApprovalHistory", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def get_vendors_to_approve(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("getVendorsToApprove", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def hold(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("hold", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def hold_revrecschedule(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("hold_revrecschedule", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def inspect(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("inspect", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def install_app(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("installApp", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def lookup(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("lookup", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def my_ach_object(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("MY_ACH_OBJECT", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def partialupdate_potransaction(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("partialupdate_potransaction", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def post(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("post", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def post_revrecscheduleentry(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("post_revrecscheduleentry", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def promote(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("promote", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def query(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("query", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def read(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("read", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def read_by_name(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("readByName", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def read_by_query(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("readByQuery", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def read_entity_details(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("readEntityDetails", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def read_more(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("readMore", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def read_related(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("readRelated", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def read_report(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("readReport", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def read_user_formatting(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("readUserFormatting", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def read_view(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("readView", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def reallocate(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("reallocate", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def reallocate_revrecschedule(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("reallocate_revrecschedule", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def reconcile_bank(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("reconcile_bank", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def record_cctransaction(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("record_cctransaction", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def record_deposit(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("record_deposit", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def record_otherreceipt(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("record_otherreceipt", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def renew(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("renew", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def resume(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("resume", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def resume_revrecschedule(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("resume_revrecschedule", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def retrievepdf(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("retrievepdf", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def reverse_appayment(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("reverse_appayment", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def reverse_arpayment(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("reverse_arpayment", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def reverse_bill(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("reverse_bill", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def reverse_cctransaction(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("reverse_cctransaction", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def reverse_expensereport(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("reverse_expensereport", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def reverse_invoice(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("reverse_invoice", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def run_dds_job(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("runDdsJob", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def send_appaymentrequest(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("send_appaymentrequest", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def terminate_revrecschedule(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("terminate_revrecschedule", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def unpost(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("unpost", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def unpost_revrecscheduleentry(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("unpost_revrecscheduleentry", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update_achbankconfiguration(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update_achbankconfiguration", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update_apaccountlabel(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update_apaccountlabel", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update_apadjustment(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update_apadjustment", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update_apterm(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update_apterm", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update_araccountlabel(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update_araccountlabel", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update_aradjustment(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update_aradjustment", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update_arterm(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update_arterm", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update_bill(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update_bill", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update_cctransaction(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update_cctransaction", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update_class(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update_class", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update_contact(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update_contact", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update_customer(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update_customer", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update_customerbankaccount(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update_customerbankaccount", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update_customerchargecard(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update_customerchargecard", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update_department(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update_department", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update_earningtype(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update_earningtype", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update_employee(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update_employee", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update_employeerate(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update_employeerate", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update_expenseadjustmentreport(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update_expenseadjustmentreport", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update_expensepaymenttype(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update_expensepaymenttype", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update_expensereport(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update_expensereport", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update_expensetype(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update_expensetype", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update_glaccount(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update_glaccount", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update_ictransaction(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update_ictransaction", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update_invoice(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update_invoice", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update_item(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update_item", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update_location(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update_location", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update_otherreceipt(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update_otherreceipt", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update_popricelist(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update_popricelist", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update_potransaction(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update_potransaction", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update_revrecschedule(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update_revrecschedule", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update_savingsaccount(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update_savingsaccount", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update_sopricelist(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update_sopricelist", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update_sotransaction(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update_sotransaction", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update_statglaccount(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update_statglaccount", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update_supdoc(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update_supdoc", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update_supdocfolder(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update_supdocfolder", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update_task(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update_task", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update_territory(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update_territory", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update_timesheet(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update_timesheet", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update_timetype(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update_timetype", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def update_vendor(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("update_vendor", payload=payload, operation_attrs=operation_attrs, control_id=control_id)

    def void_appaymentrequest(self, payload: Optional[xml_builder.Payload] = None, operation_attrs: Optional[Dict[str, str]] = None, control_id: Optional[str] = None) -> ResultData:
        return self.execute("void_appaymentrequest", payload=payload, operation_attrs=operation_attrs, control_id=control_id)
