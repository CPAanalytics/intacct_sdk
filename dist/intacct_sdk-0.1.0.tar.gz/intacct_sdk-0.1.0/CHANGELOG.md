# Changelog

## Unreleased
- Initial SDK scaffolding with auth/session and core CRUD/query operations.
- Completed endpoint catalog coverage with fixture-based integration tests and synthesized operation responses.
